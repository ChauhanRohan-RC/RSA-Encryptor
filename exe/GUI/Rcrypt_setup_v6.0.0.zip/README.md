.............................................   RCRYPT   (RC @April 12, 2020) .........................................

# A strong RSA Encryption Software

1. Uses strong asymmetric RSA Encryption algorithm
2. Supports every type of file format
3. Encrypt multiple files (of any type) in a single Batch Encryptied File (BEF) 
4. Encypted file locking and antitamper protection on Unautorised Access
5. Both Command Line (CLI) and User Interface (GUI) versions

# Usage

1. For Command Line version, download and run "exe/CLI/Rcrypt.exe"

2. For GUI version, Extract "exe/GUI/setup.zip" and install the software
3. To start RCrypt,  run RCrypt.exe
4. To Encrypt multiple files, select the desired files in the explorer -> Right Click (context menu)-> Send To -> Add to Encrypted File

# Registry Fix 

1. To fix registry problems, head to installation directory and run REG.exe
2. It will reset all registry setting for the program...

# Support

E-mail: com.production.rc@gmail.com
