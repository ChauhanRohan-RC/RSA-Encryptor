.............................................   RCRYPT   (RC @April 12, 2020) .........................................

# A strong RSA Encryption Software

* Uses strong asymmetric RSA Encryption algorithm
* Supports every type of file format
* Encrypt multiple files (of any type) in a single Batch Encrypted File (BEF) 
* Encrypted file locking and antitamper protection on Unautorised Access
* Both Command Line (CLI) and User Interface (GUI) versions

# Usage

* For Command Line version, download and run "exe/CLI/Rcrypt.exe"

* For GUI version, Extract "exe/GUI/setup.zip" and install the software
* To start RCrypt,  run RCrypt.exe
* To Encrypt multiple files, select the desired files in the explorer -> Right Click (context menu)-> Send To -> Add to Encrypted File

# Registry Fix 

* To fix registry problems, head to installation directory and run REG.exe
* It will reset all registry setting for the program...

# Support

Contact If file gets locked due to multiple Unauthorised Access
* E-mail: com.production.rc@gmail.com
